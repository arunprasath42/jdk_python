# $ErrorActionPreference = 'Stop'; # stop on all errors to enforce strict error handling
# Import-module -name D:\pkg\Chocolatey\helpers\chocolateyInstaller.psm1

# Define the tools directory, where the installation files are stored
$toolsDir   = "$(Split-Path -parent $MyInvocation.MyCommand.Definition)"

# Path to the Python 3.12.6 installer
$fileLocation = Join-Path $toolsDir 'python-3.12.6-amd64.exe'

# Define the package name
$packagename = 'python-3.12.6-amd64'

# Define the installation arguments for Chocolatey
$packageArgs = @{
  packageName   = $packagename
  fileType      = 'EXE'  # The file type is an executable installer
  file          = $fileLocation

  softwareName  = 'python-3.12.6-amd64*'  # Software name to match during installation

  # Define the silent arguments for the installer, including the custom target directory
  silentArgs    = '/passive InstallAllUsers=1 Include_launcher=1 InstallLauncherAllUsers=1 PrependPath=1 TargetDir="E:\apps\Python312"' 
  validExitCodes= @(0)  # Exit codes that are considered successful
}

# Execute the Chocolatey package installation
Install-ChocolateyPackage @packageArgs
